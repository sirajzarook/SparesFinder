USE [AdventureWorks2008]
GO

/****** Object:  StoredProcedure [dbo].[sp_SalesOrderDetailsByYear]    Script Date: 7/14/2017 9:32:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_SalesOrderDetailsByYear]
	-- Add the parameters for the stored procedure here
	@SalesYear int 

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	SELECT  CONVERT(VARCHAR(24),soh.[OrderDate],103) as OrderDate
	, CONVERT(VARCHAR(24),soh.[ShipDate],103) AS ShipDate, soh.SalesOrderID AS SalesOrderID, p.FirstName + ' ' + p.LastName as CustomerName, SUM(sod.LineTotal) AS Total
	FROM [AdventureWorks2008].[Sales].[SalesOrderHeader] soh
	INNER JOIN [AdventureWorks2008].[Sales].[SalesOrderDetail] sod  ON soh.SalesOrderID = sod.SalesOrderID
	INNER JOIN [AdventureWorks2008].[Sales].[Customer] cus ON cus.CustomerID = soh.CustomerID
	INNER JOIN [AdventureWorks2008].[Person].[Person] p ON cus.CustomerID = p.BusinessEntityID
	WHERE soh.SalesOrderID IN (SELECT SalesOrderID FROM [AdventureWorks2008].[Sales].[SalesOrderHeader] sub WHERE DATEPART(year, sub.[OrderDate]) = @SalesYear)
	GROUP BY DATEPART(year, [OrderDate]), CONVERT(VARCHAR(24),soh.[OrderDate],103), CONVERT(VARCHAR(24),soh.[ShipDate],103), soh.SalesOrderID, p.FirstName + ' ' + p.LastName
	ORDER BY CONVERT(VARCHAR(24),soh.[OrderDate],103) DESC

END
GO

