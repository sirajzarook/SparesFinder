USE [AdventureWorks2008]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetSalesByYear]    Script Date: 7/14/2017 9:31:45 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetSalesByYear]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT DATEPART(year, [OrderDate]) AS OrderYear
		  ,DATEDIFF(day, [OrderDate] ,[ShipDate]) AS TimeToShip
		  ,SUM([SubTotal]) AS Total
	FROM [AdventureWorks2008].[Sales].[SalesOrderHeader]
	GROUP BY DATEPART(year, [OrderDate]), DATEDIFF(day, [OrderDate] ,[ShipDate])
	ORDER BY DATEPART(year, [OrderDate])

END
GO

